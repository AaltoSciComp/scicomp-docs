#!/usr/bin/python

import time
import sys

print "Starting process", sys.argv[2], "of", sys.argv[1]
time.sleep(60)
print "Finishing process", sys.argv[2], "of", sys.argv[1]
