#!/usr/bin/python

import time, os

if(os.path.exists('checkpoint')):
    f = open('checkpoint','r')
    start = int(f.read()) + 1
    f.close()
else:
    start = 1

print "Starting"
for i in range(start,600):
    print i
    f = open('checkpoint','w')
    f.write(str(i))
    f.close()
    time.sleep(1)
print "Finishing"
