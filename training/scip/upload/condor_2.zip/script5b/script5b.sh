#!/bin/bash
matlab -nodesktop -nosplash -r "script5b($1,$2)"
