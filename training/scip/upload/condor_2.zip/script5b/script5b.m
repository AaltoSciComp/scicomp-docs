function script5b(numprocesses, iprocess)
    disp(['Starting process ',num2str(iprocess),' of ',num2str(numprocesses)]);
    pause(60);
    disp(['Finishing process ',num2str(iprocess),' of ',num2str(numprocesses)]);
    save(['output_' num2str(iprocess) '.mat']);
end
