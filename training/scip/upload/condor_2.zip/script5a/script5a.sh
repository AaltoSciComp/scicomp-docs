#!/bin/bash
matlab
