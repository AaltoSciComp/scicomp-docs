disp('Starting');
pause(60);
disp('Finishing');
exit
