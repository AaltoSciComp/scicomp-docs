#!/usr/bin/python

import time

print "Starting"
time.sleep(60)
print "Finishing"
