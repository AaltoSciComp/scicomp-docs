#!/usr/bin/python

import time, os, signal

if(os.path.exists('checkpoint')):
    f = open('checkpoint','r')
    start = int(f.read()) + 1
    f.close()
else:
    start = 1

def handler(signum, frame):
    f = open('checkpoint','w')
    f.write(str(i))
    f.close()
    exit(1)

signal.signal(signal.SIGTERM, handler)

print "Starting"
for i in range(start,120):
    print i
    time.sleep(1)
print "Finishing"
